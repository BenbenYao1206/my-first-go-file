class User{
    constructor(name,pass,cpass, phone){
        this.name=name;
        this.pass=pass;
        this.cpass=cpass;
        this.phone=phone;
      
        

    }
}
module.exports=User;